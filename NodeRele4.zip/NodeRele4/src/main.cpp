#include <Arduino.h>

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>

const char *ssid = "WIFI_REL_NODEMCU";
const char *password = "wifirelpassword";

IPAddress ip(192, 168, 4, 1);
IPAddress netmask(255, 255, 255, 0);
const int port = 8080; // Port
ESP8266WebServer server(port);


/// D1,D2,D5,D6      

//  5, 4, 14, 12

static const uint8_t rele1 = 5;
static const uint8_t rele2 = 4;
static const uint8_t rele3 = 14;
static const uint8_t rele4 = 12;


int estado1=0;
int estado2=0;
int estado3=0;
int estado4=0;



void handleNotFound() {
  server.send(404, "text / plain", "404: Not found");
}


void activar_rele1() {

if (estado1==0){

digitalWrite(rele1,LOW);
estado1=1;
} else {

digitalWrite(rele1,HIGH);
estado1=0;

}


}


void activar_rele2() {

if (estado2==0){

digitalWrite(rele2,LOW);
estado2=1;
} else {

digitalWrite(rele2,HIGH);
estado2=0;

}

}

void activar_rele3() {

if (estado3==0){

digitalWrite(rele3,LOW);
estado3=1;
} else {

digitalWrite(rele3,HIGH);
estado3=0;

}
}

void activar_rele4() {

if (estado4==0){

digitalWrite(rele4,LOW);
estado4=1;
} else {

digitalWrite(rele4,HIGH);
estado4=0;

}

}


void handleActionRequest() {
  if (!server.hasArg("type")) {
    server.send(404, "text / plain", "Action: undefined");
    return;
  }
  String type = server.arg("type");
  if (type.equals("1")) {
    
    activar_rele1();

    server.send(200, "text / plain", "Action 1");
  }
  else if (type.equals("2")) {
    activar_rele2();
    server.send(200, "text / plain", "Action 2");
  }
  else if (type.equals("3")) {
    activar_rele3();
    server.send(200, "text / plain", "Action 3");
  }
  else if (type.equals("4")) {
   activar_rele4();
    server.send(200, "text / plain", "Action 4");
  }
  else if (type.equals("5")) {
    // TODO : Action 5
    server.send(200, "text / plain", "Action 5");
  }
  else if (type.equals("6")) {
    // TODO : Action 6
    server.send(200, "text / plain", "Action 6");
  }
  else if (type.equals("7")) {
    // TODO : Action 7
    server.send(200, "text / plain", "Action 7");
  }
  else if (type.equals("8")) {
    // TODO : Action 8
    server.send(200, "text / plain", "Action 8");
  }
  else {
    server.send(404, "text / plain", "Action: undefined");
  }
}

// Motor speed = [0-1024]

void setup() {
  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(ip, ip, netmask);
  WiFi.softAP(ssid, password);

  pinMode(rele1, OUTPUT); // PMW A
  pinMode(rele2, OUTPUT); // PMW B
  pinMode(rele3, OUTPUT); // DIR A
  pinMode(rele4, OUTPUT); // DIR B


  server.on("/action", HTTP_GET, handleActionRequest);
  server.onNotFound(handleNotFound);
  server.begin();
}

void loop() {
  server.handleClient();
}







